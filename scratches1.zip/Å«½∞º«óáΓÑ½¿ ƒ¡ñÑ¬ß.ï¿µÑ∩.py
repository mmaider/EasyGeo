# -*- coding: utf8 -*-

import pygame
import copy
import random
import requests
import sys
import os
import math

lat_step = 0.008
lon_step = 0.002
coords_to_geo_x = 0.0000428
coords_to_geo_y = 0.0000428
global_lat = random.uniform(-150, 150)
global_lon = random.uniform(-70, 70)
flag = False
map_file = None
score = 0
z = 1

pygame.init()
size = width, height = 700, 400
screen = pygame.display.set_mode(size)
pygame.display.set_caption("EasyGeo")
screen.fill((255, 255, 255))
clock = pygame.time.Clock()
running = True
start_running = True
atlas_running = False
mode = -1
hp = 100
answer = ''
geocoder_request = "http://geocode-maps.yandex.ru/1.x/?geocode=" + str(global_lat) + ', ' + str(
    global_lon) + "&format=json"
response = requests.get(geocoder_request)
json_response = response.json()
toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"][
    "metaDataProperty"]["GeocoderMetaData"]
type = toponym['kind']
obj = toponym['text']
print(type, obj)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    image = image.convert_alpha()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    return image


class MainMenu:
    def start_screen():
        global running, start_running, rules_running, atlas_running, screen, size, mode
        pygame.init()
        size = width, height = 700, 400
        screen = pygame.display.set_mode(size)
        intro_text = ['EasyGeo',
                      'Изучай геграфию с удовольствием!']
        buttons = ['Начать']
        rules = ['Правила игры']
        atlas = ['Атлас']
        fon = pygame.transform.scale(load_image('rules_fon.jpg'), (700, 450))
        screen.blit(fon, (0, 0))
        font = pygame.font.SysFont('serif', 35)
        text_coord = 30
        for line in intro_text:
            string_rendered = font.render(line, 1, (255, 255, 255))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 350 - (intro_rect.width // 2)
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)
        font = pygame.font.SysFont('serif', 20)
        text_coord = 160
        for line in rules:
            string_rendered = font.render(line, 1, (255, 255, 255))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 350 - (intro_rect.width // 2)
            # print(intro_rect)
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)

        font = pygame.font.SysFont('serif', 20)
        for line in buttons:
            string_rendered = font.render(line, 1, (255, 255, 255))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 350 - (intro_rect.width // 2)
            # print(intro_rect)
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)

        font = pygame.font.SysFont('serif', 20)
        for line in atlas:
            string_rendered = font.render(line, 1, (255, 255, 255))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 350 - (intro_rect.width // 2)
            print(intro_rect)
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)
        while start_running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    start_running = False
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if (event.pos[0] > 278 and event.pos[0] < (278 + 145) and
                            event.pos[1] > 170 and event.pos[1] < (170 + 26)):
                        start_running = False
                        rules_running = True
                    elif (event.pos[0] > 321 and event.pos[0] < (321 + 59) and
                          event.pos[1] > 206 and event.pos[1] < (206 + 23)):
                        mode = 0
                        start_running = False
                        size = width, height = 700, 400
                        screen = pygame.display.set_mode(size)
                    elif (event.pos[0] > 325 and event.pos[0] < (325 + 51) and
                          event.pos[1] > 236 and event.pos[1] < (236 + 23)):
                        start_running = False
                        atlas_running = True
            pygame.display.flip()
            clock.tick(20)


class Rules:
    def start_screen():
        global running, start_running, rules_running, screen, size, mode
        intro_text = ['Правила игры']
        rules_text = ['1) Чтобы начать игру, выберите соотвествующий пункт в меню.',
                      '2) После начала игры на карте будет отмечено место.',
                      '3) Вы можете приближать и отдалять карту.',
                      '4) Вам будут предложены вопросы. Ваша цель - правильно ответить на них.',
                      '5) За правильные ответы вы будете получать очки. Чем больше - тем лучше.',
                      'Развивайте свои познания в географии через игру!']
        main_text = ['В главное меню']
        fon = pygame.transform.scale(load_image('rules_fon.jpg'), (700, 450))
        screen.blit(fon, (0, 0))
        font = pygame.font.SysFont('serif', 35)
        text_coord = 30
        for line in intro_text:
            string_rendered = font.render(line, 1, (255, 255, 255))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 10
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)
        font = pygame.font.SysFont('serif', 20)
        for line in rules_text:
            string_rendered = font.render(line, 1, (230, 230, 230))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 10
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)
        font = pygame.font.SysFont('serif', 25)
        for line in main_text:
            string_rendered = font.render(line, 1, (255, 255, 255))
            intro_rect = string_rendered.get_rect()
            text_coord += 10
            intro_rect.top = text_coord
            intro_rect.x = 10
            # print(intro_rect)
            text_coord += intro_rect.height
            screen.blit(string_rendered, intro_rect)
            font = pygame.font.SysFont('serif', 20)
        while rules_running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    rules_running = False
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if (event.pos[0] > 10 and event.pos[0] < 146
                            and event.pos[1] > 292 and event.pos[1] < 315):
                        start_running = True
                        rules_running = False
            pygame.display.flip()
            clock.tick(20)


class Map(object):
    def __init__(self):
        global global_lat, global_lon, z
        self.pt = '&pt={},{},pm2rdm'.format(global_lat, global_lon)
        self.z = z
        self.type = "sat"
        self.search_result = None
        self.use_postal_code = False

    def update(self, event):
        global answer, running, start_running, obj, type, flag, global_lat, global_lon, map_file, score, z
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_PAGEUP and self.z < 10:
                self.z += 1
                z += 1
            elif event.key == pygame.K_PAGEDOWN and self.z > 1:
                self.z -= 1
                z -= 1
            elif event.key == pygame.K_BACKSPACE:
                answer = answer[:-1]
            elif event.key == pygame.K_RETURN:
                if flag == True:
                    flag = False
                    global_lat = random.uniform(-150, 150)
                    global_lon = random.uniform(-70, 70)
                    answer = ''
                    geocoder_request = "http://geocode-maps.yandex.ru/1.x/?geocode=" + str(global_lat) + ', ' + str(
                        global_lon) + "&format=json"
                    response = requests.get(geocoder_request)
                    json_response = response.json()
                    toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"][
                        "metaDataProperty"]["GeocoderMetaData"]
                    type = toponym['kind']
                    obj = toponym['text']
                    map_file = load_map(Map())
                    print(type, obj)
                else:
                    if (answer != '') and (answer in obj.lower()):
                        score += len(''.join(answer.split())) / len(''.join(obj.split()))
                        answer = 'Вы правы! Обновить карту (на enter)?'
                        flag = True
                    else:
                        answer = 'Нет! Попробуйте ещё раз!'
            else:
                answer += event.unicode


def load_map(mapp):
    if running:
        map_request = "http://static-maps.yandex.ru/1.x/?ll={},{}&z={z}&l={type}{pt}".format(global_lat, global_lon,
                                                                                             z=mapp.z,
                                                                                             type=mapp.type, pt=mapp.pt)

        response = requests.get(map_request)
        if not response:
            print("Ошибка выполнения запроса:")
            print(map_request)
            print("Http статус:", response.status_code, "(", response.reason, ")")
            sys.exit()
        map_file = "map.png"
        try:
            with open(map_file, "wb") as file:
                file.write(response.content)
        except IOError as ex:
            print("Ошибка записи временного файла:", ex)
            sys.exit(2)
        return map_file


def main_cycle():
    global running, start_running, rules_running, screen, size, mode, answer, obj, type, map_file, score
    if running:
        pygame.init()
        screen = pygame.display.set_mode((600, 450))
        font = pygame.font.SysFont('verdana', 15)
        while pygame.event.wait().type != pygame.QUIT:
            mapp = Map()
            event = pygame.event.wait()
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if (event.pos[0] > 0 and event.pos[0] < 130
                        and event.pos[1] > 430 and event.pos[1] < 460):
                    start_running = True
                    break
            if running:
                mapp.update(event)
                map_file = load_map(mapp)
                screen.blit(pygame.image.load(map_file), (0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (0, 0, 600, 30))
                if answer != '':
                    string_rendered = font.render(answer, 2, (0, 0, 0))
                    intro_rect = string_rendered.get_rect()
                    screen.blit(string_rendered, intro_rect)
                else:
                    string_rendered = font.render('Тип объекта:' + type, 2, (0, 0, 0))
                    intro_rect = string_rendered.get_rect()
                    screen.blit(string_rendered, intro_rect)
                string_rendered = font.render('В главное меню', 1, (0, 0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (0, 430, 130, 30))
                intro_rect = string_rendered.get_rect()
                intro_rect.y += 430
                screen.blit(string_rendered, intro_rect)

                string_rendered = font.render('Очки:' + str(score), 1, (0, 0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (470, 0, 130, 30))
                intro_rect = string_rendered.get_rect()
                intro_rect.x += 470
                intro_rect.y = 0
                screen.blit(string_rendered, intro_rect)
                pygame.display.flip()
        pygame.quit()
        os.remove(map_file)


class Atlas(object):
    def __init__(self):
        self.lat = 37.653452
        self.lon = 55.721555
        self.z = 2
        self.type = "sat%2Cskl"

    def update(self, event):
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_PAGEUP and self.z < 19:
                self.z += 1
            elif event.key == pygame.K_PAGEDOWN and self.z > 1:
                self.z -= 1
            elif pygame.key.get_pressed()[pygame.K_LEFT]:
                self.lat -= lat_step * math.pow(2, 15 - self.z)
            elif pygame.key.get_pressed()[pygame.K_RIGHT]:
                self.lat += lat_step * math.pow(2, 15 - self.z)
            elif pygame.key.get_pressed()[pygame.K_UP]:
                self.lon += lon_step * math.pow(2, 15 - self.z)
            elif pygame.key.get_pressed()[pygame.K_DOWN]:
                self.lon -= lon_step * math.pow(2, 15 - self.z)


def atlas(mapp):
    if running:
        map_request = "http://static-maps.yandex.ru/1.x/?ll={},{}&z={z}&l={type}".format(mapp.lat, mapp.lon,
                                                                                         z=mapp.z,
                                                                                         type=mapp.type)

        response = requests.get(map_request)
        if not response:
            print("Ошибка выполнения запроса:")
            print(map_request)
            print("Http статус:", response.status_code, "(", response.reason, ")")
            sys.exit()
        map_file = "map.png"
        try:
            with open(map_file, "wb") as file:
                file.write(response.content)
        except IOError as ex:
            print("Ошибка записи временного файла:", ex)
            sys.exit(2)
        return map_file


def atlas_start():
    global running, start_running, atlas_running
    mapp = Atlas()
    if running:
        pygame.init()
        screen = pygame.display.set_mode((600, 450))
        font = pygame.font.SysFont('verdana', 15)
        while pygame.event.wait().type != pygame.QUIT:
            event = pygame.event.wait()
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if (event.pos[0] > 0 and event.pos[0] < 130
                        and event.pos[1] > 430 and event.pos[1] < 460):
                    start_running = True
                    atlas_running = False
                    break
            if running:
                mapp.update(event)
                map_file = atlas(mapp)
                screen.blit(pygame.image.load(map_file), (0, 0))

                string_rendered = font.render('В главное меню', 1, (0, 0, 0))
                pygame.draw.rect(screen, (255, 255, 255), (0, 430, 130, 30))
                intro_rect = string_rendered.get_rect()
                intro_rect.y += 430
                screen.blit(string_rendered, intro_rect)

                pygame.display.flip()
        pygame.quit()
        os.remove(map_file)


wasted = False
rules_running = False
second_fon = load_image('second_fon.png')
up = False
down = False
updelta = 10
downdelta = -10

while running:
    if start_running:
        MainMenu.start_screen()
    elif rules_running:
        Rules.start_screen()
    elif atlas_running:
        atlas_start()
    else:
        main_cycle()
pygame.quit()
